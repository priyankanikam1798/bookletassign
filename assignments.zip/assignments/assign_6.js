function compoundInterest()
{
    var p = document.getElementById('principal').value;
    var r = document.getElementById('interest').value;
    var n = document.getElementById('time').value;
    var amt;
    
    amt = ((p*(1+r/100)^n)-p);
    alert(amt);
}