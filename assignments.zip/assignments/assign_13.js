class point{
    constructor()
    {
        this.x1;
        this.x2;
        this.y1;
        this.y2;
    }
}

class shape{
    constructor()
    {
        
    }
}