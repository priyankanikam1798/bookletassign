var students = [];

function add(){
    var input = document.getElementById("inputstud").value;
    students.push(input);
    
}
function display(){
        for(var i=0;i<students.length;i++){
            document.writeln("List of students in array : ");
            document.writeln(students[i]);
        }
}
