function printNumbers(){
    var i=1;
    var count=0;
    for(i;i<=100;i++)
    {
        
        document.write(i);
        count++;
        if(count==10)
        {
            count=0;
            document.writeln();
            //break;
        }
    }
}
